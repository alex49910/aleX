var counter = 0;
var timeleft = 80;// easymode = 80 || normalmode = 60 ||hardmode = 40

function convertSeconds (s){
  var min = floor(s / 60);
  var sec = s % 60;
  return min + ':' + sec;
}
function setup() {
  noCanvas();

  var timer  =  select('#timer');
  timer.html(convertSeconds(timeleft - counter));

  function timeIt(){
    counter++;
    timer.html(convertSeconds(timeleft - counter));
  }
  setInterval(timeIt, 1000);
}
