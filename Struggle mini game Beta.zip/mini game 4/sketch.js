let bubbles = [];

var score = 0;

var touched = false;
var prevTouched = touched;

var issOver = false;

var counter = 0;
var timeleft = 10;// 45 seconds on every mode 5s to spawn a random ellipse|| rope picture
//var sound //you can use soundtraks for the losing screen;
function convertSeconds (s){
  var min = floor(s / 60);
  var sec = s % 60;
  return nf(min , 2) + ':' + nf(sec , 2);
}

function setup() {
  createCanvas(1200, 675);
  for (let i = 0; i < 4; i++) {
    let x = random(100,1000);
    let y = random(100,500);
    let r = random(30, 30);
    let b = new Bubble(x, y, r);
    bubbles.push(b);
  }

  var params = getURLParams();
  if ( params.minute){
    var min = params.minute;
    timeleft = min * 60;
  }
  var timer  =  select('#timer');
  timer.html(convertSeconds(timeleft - counter));// id html timer

  var interval = setInterval(timeIt, 1000); // goes --up or ++down by 1 sec
  function timeIt(){
    counter++;
    timer.html(convertSeconds(timeleft - counter));
    if ( counter == timeleft){
      clearInterval(interval);

    }
  }
}



function mousePressed() {
  for (let i = 0; i < bubbles.length; i++) {
    bubbles[i].clicked(mouseX,mouseY);
  }
}


function draw() {
  background(0);
  for (let i = 0; i < bubbles.length; i++) {
    bubbles[i].move();
    bubbles[i].show();

    if(score > 3){
      gamewwon();
    }
    if(counter > 9.9){ // = timeleft -0,1
      gamellost();
    }
  }
  showScores();
  touched = (touches.length > 0);

  prevTouched = touched;
}

class Bubble {
  constructor(x, y, r) {
    this.x = x;
    this.y = y;
    this.r = r;
    this.brightness = 0;

  }

  clicked(px,py) { // cheks the distance between mouse and struggle ellipse
    let d = dist( px, py, this.x, this.y);
    if (d < this.r) {
      this.brightness = 255;
      score++;
    }
  }

  move() {
    this.x = this.x + random(-10, 10);// 5 easy mode, 10 normal mode , 15 hard mode
    this.y = this.y + random(-10, 10);// 5 easy mode, 10 normal mode , 15 hard mode
  }

  show() {
    stroke(255);
    strokeWeight(4);
    fill(this.brightness, 125);
    ellipse(this.x, this.y, this.r * 2);
  }
}

function gamewwon(){
  fill(0,200,0);
  textSize(64);
  text('You struggled out off the rope',100,300);
  noloop();
  issOver = true;
}

function gamellost(){
  fill(200,0,0);
  textSize(64);
  text('You struggle, but nothing happend',100,300);
  noloop();
  issOver = true;
}
function showScores(){
  fill(0,0,200);
  textSize(32);
  text('score :' +score,1050,660);
  text('press the mouse to get points',400,660);
}
function reset(){
  issOver = false;
  score = 0;
  b = new Bubble();
  loop();

}
function keyPressed(){
  if(key === ' '){
    bubbles.push();
    if (issOver) reset();
  }
}

function toucheStarted(){
  if (issOver) reset();
}

// timer = 0 gameover
// score is less than 9 gameover
// score is above 10 gamewon
// every 5 seconds spawning new ellipse's
